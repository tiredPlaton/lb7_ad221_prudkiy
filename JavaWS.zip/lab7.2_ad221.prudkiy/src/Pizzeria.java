import java.util.Scanner;
class Pizzeria {
    Item[] pizzas = new Item[PizzaType.values().length];
    Item[] drinks = new Item[DrinkType.values().length];

    public void run() {
        for (PizzaType type : PizzaType.values()) {
            pizzas[type.ordinal()] = new Item(type.name());
        }
        for (DrinkType type : DrinkType.values()) {
            drinks[type.ordinal()] = new Item(type.name());
        }

        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nДобро пожаловать в нашу пиццерию! Выберите пиццу (или введите 0, чтобы пропустить):");
            displayMenu(pizzas);
            int pizzaChoice = getValidInput(scanner, pizzas.length);
            if (pizzaChoice != 0) {
                updateOrder(scanner, pizzas[pizzaChoice - 1]);
            }

            System.out.println("\nТеперь выберите напиток (или введите 0, чтобы пропустить):");
            displayMenu(drinks);
            int drinkChoice = getValidInput(scanner, drinks.length);
            if (drinkChoice != 0) {
                updateOrder(scanner, drinks[drinkChoice - 1]);
            }

            printReceipt();
        }
    }

    public void displayMenu(Item[] items) {
        for (int i = 0; i < items.length; i++) {
            System.out.println((i + 1) + ". " + items[i].name);
        }
    }

    public int getValidInput(Scanner scanner, int max) {
        int choice;
        do {
            while (!scanner.hasNextInt()) {
                System.out.println("Это не число. Пожалуйста, введите число:");
                scanner.next();
            }
            choice = scanner.nextInt();
            if (choice < 0 || choice > max) {
                System.out.println("Недопустимый выбор. Пожалуйста, введите число от 0 до " + max + ":");
            }
        } while (choice < 0 || choice > max);
        return choice;
    }

    public void updateOrder(Scanner scanner, Item item) {
        System.out.println("Введите количество:");
        int quantity = getValidInput(scanner, Integer.MAX_VALUE);
        item.quantity += quantity;
        System.out.println("Вы добавили " + quantity + " " + item.name);
    }

    public void printReceipt() {
        System.out.println("\nВаш чек:");
        printItems(pizzas);
        printItems(drinks);
        System.out.println();
    }

    public void printItems(Item[] items) {
        for (Item item : items) {
            if (item.quantity > 0) {
                System.out.println(item.name + ": " + item.quantity);
            }
        }
    }
}