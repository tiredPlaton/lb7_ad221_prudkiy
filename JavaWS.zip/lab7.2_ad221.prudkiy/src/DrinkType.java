import java.util.Scanner;
enum DrinkType {
    COLA, FANTA, SPRITE, TEA, BLACK_COFFEE, COFFEE_WITH_MILK
}