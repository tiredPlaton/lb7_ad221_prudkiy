import java.util.Scanner;
class Item {
    String name;
    int quantity;
    Item(String name) {
        this.name = name;
        this.quantity = 0;
    }
}