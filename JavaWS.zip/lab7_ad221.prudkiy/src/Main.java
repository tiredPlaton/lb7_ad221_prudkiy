import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        School.Season[] seasons = School.Season.values();
        School.Season randomSeason = seasons[random.nextInt(seasons.length)];

        School mySchool = new School(500, randomSeason);
        System.out.println("Кількість учнів в школі: " + mySchool.getNumberOfStudents());
        System.out.println("Поточна пора року: " + mySchool.getCurrentSeason().getSeasonName());
    }
}