public class School {
    private int numberOfStudents;
    private Season currentSeason;

    public School(int numberOfStudents, Season currentSeason) {
        this.numberOfStudents = numberOfStudents;
        this.currentSeason = currentSeason;
    }

    public enum Season {
        WINTER("Winter"),
        SPRING("Spring"),
        SUMMER("Summer"),
        AUTUMN("Autumn");

        private String seasonName;

        Season(String seasonName) {
            this.seasonName = seasonName;
        }

        public String getSeasonName() {
            return this.seasonName;
        }
    }

    public int getNumberOfStudents() {
        return this.numberOfStudents;
    }

    public Season getCurrentSeason() {
        return this.currentSeason;
    }
}
