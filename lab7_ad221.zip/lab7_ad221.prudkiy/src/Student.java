public class Student extends Person {
    private String group;
    private String ticketNumber;

    // Гетери
    public String getGroup() {
        return group;
    }
    public String getTicketNumber() {
        return ticketNumber;
    }

    // Сетери
    public void setGroup(String group) {
        this.group = group;
    }
    public void setTicketNumber(String ticketNumber) {
        this.ticketNumber = ticketNumber;
    }

    // Перевизначений метод printInfo
    @Override
    public String printInfo() {
        return "Студент групи " + group + " " + getSurname() + " " + getName() + ", вік: " + getAge() + ". Номер студентського квитка: " + ticketNumber;
    }
}