public enum PersonType {
    STUDENT,
    LECTURER
}
