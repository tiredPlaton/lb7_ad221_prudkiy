public class PersonFactory {
    public static Person createPerson(PersonType type) {
        switch (type) {
            case STUDENT:
                return new Student();
            case LECTURER:
                return new Lecturer();
            default:
                throw new IllegalArgumentException("Invalid person type");
        }
    }
}