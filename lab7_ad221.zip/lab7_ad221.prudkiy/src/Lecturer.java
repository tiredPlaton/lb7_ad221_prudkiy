public class Lecturer extends Person {
    private String department;
    private double salary;

    // Гетери
    public String getDepartment() {
        return department;
    }

    public double getSalary() {
        return salary;
    }

    // Сетери
    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    // Перевизначений метод printInfo
    @Override
    public String printInfo() {
        return "Викладач кафедри " + department + " " + getSurname() + " " + getName() + ", вік: " + getAge() + ". Зарплата: " + salary;
    }
}
