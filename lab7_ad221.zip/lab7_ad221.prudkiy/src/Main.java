public class Main {
    public static void main(String[] args) {
        // Створення об'єктів класів Student і Lecturer за допомогою фабричного методу
        Student student1 = (Student) PersonFactory.createPerson(PersonType.STUDENT);
        student1.setName("Дмитро");
        student1.setSurname("Прудкий");
        student1.setAge(18);
        student1.setGroup("АД-221");
        student1.setTicketNumber("20052507");

        Lecturer lecturer1 = (Lecturer) PersonFactory.createPerson(PersonType.LECTURER);
        lecturer1.setName("Михайло");
        lecturer1.setSurname("Петрович");
        lecturer1.setAge(56);
        lecturer1.setDepartment("Інформаційні технології");
        lecturer1.setSalary(24000.0);

        // Створення масиву, який може включати об'єкти класів Person, Student, Lecturer
        Person[] persons = new Person[2];

        // Заповнення масиву об'єктами цих класів
        persons[0] = student1;
        persons[1] = lecturer1;

        // Виведення інформації про кожну особу в масиві
        for (Person person : persons) {
            System.out.println(person.printInfo());
        }
    }
}